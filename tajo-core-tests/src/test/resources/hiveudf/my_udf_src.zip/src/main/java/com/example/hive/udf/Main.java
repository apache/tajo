package com.example.hive.udf;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;

public class Main {
  public static void main(String [] args) {
    MyUpper upper = new MyUpper();

    Writable result = upper.evaluate(null);

    System.out.println(result.toString());
  }
}
