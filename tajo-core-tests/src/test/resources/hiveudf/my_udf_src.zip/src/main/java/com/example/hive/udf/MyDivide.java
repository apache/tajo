package com.example.hive.udf;

import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;

@Description(
    name = "my_divide",
    value = "divide first integer by second integer",
    extended = "my_divide(INT, INT)"
)
public class MyDivide extends UDF {
  public DoubleWritable evaluate(final IntWritable first, final IntWritable second) {
    int i1 = first.get();
    int i2 = second.get();

    return new DoubleWritable(i1 / (double)i2);
  }
}
