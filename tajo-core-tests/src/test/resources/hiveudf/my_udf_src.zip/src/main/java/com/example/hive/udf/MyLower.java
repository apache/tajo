package com.example.hive.udf;

import org.apache.hadoop.hive.ql.exec.UDF;
import org.apache.hadoop.io.Text;

public class MyLower extends UDF {
  public Text evaluate(final Text s) {
    if (s == null) return null;

    return new Text(s.toString().toLowerCase());
  }

  public Text evaluate(final Text s1, final Text s2) {
    if (s1 == null || s2 == null) {
      return null;
    }

    return new Text(s1.toString().toLowerCase()+s2.toString().toLowerCase());
  }
}
