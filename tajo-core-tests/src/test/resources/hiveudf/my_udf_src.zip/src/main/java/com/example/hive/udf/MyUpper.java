package com.example.hive.udf;

import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;
import org.apache.hadoop.io.Text;

@Description(
    name = "my_upper,test_upper",
    value = "to uppercase",
    extended = "upper(STRING)"
)
public class MyUpper extends UDF {
  public Text evaluate(final Text s) {
    if (s == null) return null;

    return new Text(s.toString().toUpperCase());
  }
}
